/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uav.mosa.struct;

/**
 *
 * @author jesimar
 */
public class Constants {
    
    public static String NAME_DRONE_ARARINHA     = "ARARINHA";
    public static String NAME_DRONE_iDRONE_ALPHA = "iDRONE_ALPHA";
        
    public static String SYS_EXEC_GPS_ANALYSER = "GPS_ANALYSER";
    public static String SYS_EXEC_POS_ANALYSER = "POS_ANALYSER";
    public static String SYS_EXEC_ROUTE_READY  = "ROUTE_READY";
    public static String SYS_EXEC_PLANNER      = "PLANNER";
    
    public static String COMMAND_NONE = "NONE";
    public static String COMMAND_LAND = "LAND";
    public static String COMMAND_RTL  = "RTL";
    
    public static String FORM_DATA_ACQUISITION_TOTAL   = "TOTAL";
    public static String FORM_DATA_ACQUISITION_PARTIAL = "PARTIAL";
    
}
